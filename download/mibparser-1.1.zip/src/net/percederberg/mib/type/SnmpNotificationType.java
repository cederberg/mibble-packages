/*
 * @(#)SnmpNotificationType.java
 *
 * This work is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This work is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * Copyright (c) 1999 Ericsson Telecom. All rights reserved.
 * Copyright (c) 2003 Per Cederberg. All rights reserved.
 */

package net.percederberg.mib.type;

/**
 * A class for handling type information for the SNMP notification 
 * type macro type.
 *
 * @version  1.1
 * @author   Per Cederberg, per@percederberg.net
 */
public class SnmpNotificationType extends Type {
    // TODO: add varible for the object values
    // TODO: add methods for reading the instance variables

    /**
     * The status value.
     * 
     * @see net.percederberg.mib.type.SnmpObjectType#status
     */
    private int status = -1;

    /**
     * The description text.
     */
    private String description = null;

    /**
     * The optional reference text.
     */
    private String reference = null;

    /**
     * Creates a new SNMP notification type with the specified values. 
     * The reference text will be set to null.
     *
     * @param status    the status value
     * @param desc      the module description
     */
    public SnmpNotificationType(int status, String desc) {
        this(status, desc, null);
    }

    /**
     * Creates a new SNMP notification type with the specified values.
     *
     * @param status    the status value
     * @param desc      the module description
     * @param ref       the reference text
     */
    public SnmpNotificationType(int status, String desc, String ref) {
        this.status = status;
        this.description = desc;
        this.reference = ref;
    }

    /**
     * Checks if this type equals another.
     *
     * @param  obj       an object
     * @return true if the types are equal, false otherwise
     */
    public boolean equals(Object obj) {
        return this == obj;
    }

    /**
     * Returns a description of this type.
     *
     * @return a description of the type
     */
    public String toString() {
        return "NotificationType";
    }

    /**
     * Transfers the type information from this type to a type
     * converter object. The calling conventions declared in the
     * TypeConverter class are followed.
     *
     * @param   converter     a type converter
     */
    public void transferType(TypeConverter converter) {
        throw new UnsupportedOperationException(
            "This type cannot be mapped to anything.");
    }
}
