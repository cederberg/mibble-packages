/*
 * @(#)ValueConstraint.java        1.0         6 September 1999
 *
 * This work is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This work is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * Copyright (c) 1999 Ericsson Telecom. All rights reserved.
 * Copyright (c) 2002 Per Cederberg. All rights reserved.
 */

package net.percederberg.mib.type;

/**
 * A class representing a single value constraint.
 *
 * @version  1.0
 * @author   Per Cederberg, per@percederberg.net
 */
public class ValueConstraint extends Constraint {

    /**
     * The constraint value.
     */
    private Number value;

    /**
     * Creates a new value constraint with the given value.
     *
     * @param  value    the constraint value
     */
    public ValueConstraint(Number value) {
        this.value = value;
    }

    /**
     * Checks if this constraint equals another constraint.
     *
     * @param obj    the object to compare with
     *
     * @return true if the objects are equal, or
     *         false otherwise
     */
    public boolean equals(Object obj) {
        if (obj instanceof ValueConstraint) {
            return this.value.equals(((ValueConstraint) obj).value);
        } else {
            return false;
        }
    }

    /**
     * Returns a string description of this constraint.
     *
     * @return a string description
     */
    public String toString() {
        return value.toString();
    }

    /**
     * Transfers the constraint information from this object to a type
     * converter object. The calling conventions declared in the
     * TypeConverter class are followed.
     *
     * @param   converter     a type converter
     */
    public void transferConstraint(TypeConverter converter) {
        converter.transferValueLimits(value(), value());
    }

    /**
     * Returns the integer value for this constraint.
     *
     * @return   the integer value
     */
    protected int value() {
        if (value.longValue() < Integer.MIN_VALUE) {
            return Integer.MIN_VALUE;
        } else if (value.longValue() > Integer.MAX_VALUE) {
            return Integer.MAX_VALUE;
        } else {
            return value.intValue();
        }
    }

}
